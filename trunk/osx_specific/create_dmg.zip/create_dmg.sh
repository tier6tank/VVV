#!/bin/bash

# change these
VOLUME_NAME="VVV-1.3"
DMG_NAME=VVV-1.3-i386.dmg

# this script creates a disk image for software distribution in the current folder,
# copying the content from the app in the ../installed_cocoa_301 folder

# Create an initial disk image (32 megs)
hdiutil create -size 32m -fs HFS+ -volname ${VOLUME_NAME} temp.dmg

# Mount the disk image
hdiutil attach temp.dmg

# copy files to the disk image
cp -R Applications /Volumes/${VOLUME_NAME}
cp -R ../installed_cocoa_301/VVV.app /Volumes/${VOLUME_NAME}

# Unmount the disk image
hdiutil detach /Volumes/${VOLUME_NAME}

# Convert the disk image to read-only
hdiutil convert temp.dmg -format UDZO -o ${DMG_NAME}

